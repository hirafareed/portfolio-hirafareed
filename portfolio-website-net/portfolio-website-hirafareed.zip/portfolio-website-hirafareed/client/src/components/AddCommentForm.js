import React, { useState } from "react";
import "../sass/style.scss";

const AddCommentForm = ({ articleName, setArticleInfo }) => {
  const [username, setUsername] = useState("");
  const [commentText, setCommentText] = useState("");

  const addComment = async () => {
    const result = await fetch(`/api/articles/${articleName}/add-comment`, {
      method: "post",
      body: JSON.stringify({ username, text: commentText }),
      headers: {
        "Content-Type": "application/json",
      },
    });
    const body = await result.json();
    setArticleInfo(body);
    setUsername("");
    setCommentText("");
  };

  return (
    <div>
      <div className=" row form-group">
        <input
          className="col-lg-4 form-control"
          type="text"
          value={username}
          placeholder="Your name ..."
          onChange={(event) => setUsername(event.target.value)}
        />
      </div>

      <div className="row form-group">
        <textarea
          className="col form-control"
          rows="4"
          value={commentText}
          placeholder="What are your thoughts on this project?"
          onChange={(event) => setCommentText(event.target.value)}
        />
      </div>

      <button className="comment-button " disabled={!username || !commentText} onClick={() => addComment()}>
        Comment
      </button>
    </div>
  );
};

export default AddCommentForm;
