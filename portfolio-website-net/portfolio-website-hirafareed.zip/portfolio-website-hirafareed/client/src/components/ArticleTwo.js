import React, { useEffect, useState } from "react";
import TopSection from "./ArticleTopSection/ArticleTopSection";
import Data from "./../pages/article-content";
import { Link } from "react-router-dom";
import CommentsList from "../components/CommentsList";
import AddCommentForm from "./AddCommentForm";
import UpvotesSection from "./UpvotesSection";

export default ({ match }) => {
  const name = match.params.name;

  console.log(name);

  const [articleInfo, setArticleInfo] = useState({ upvotes: 0, comments: [] });

  const item1 = Data.find((x) => x.id === "01");
  const item2 = Data.find((x) => x.id === "02");
  const item3 = Data.find((x) => x.id === "03");

  useEffect(() => {
    const fetchData = async () => {
      const result = await fetch(`/api/articles/${name}`);
      const body = await result.json();
      setArticleInfo(body);
      // console.log(body);
    };
    fetchData();
  }, [name]);

  return (
    <>
      <TopSection data={item2}></TopSection>
      <div className="mb-5 mt-5">
        <h1>Article two bottom part</h1>
        <h2>{item2.name}</h2>
        <UpvotesSection
          articleName={name}
          upvotes={articleInfo && articleInfo.upvotes ? articleInfo.upvotes : 0}
          setArticleInfo={setArticleInfo}
        />

        <CommentsList comments={articleInfo && articleInfo.comments ? articleInfo.comments : null} />
        <AddCommentForm articleName={name} setArticleInfo={setArticleInfo} />
      </div>
      <hr></hr>
      <div className="mt-5">
        <div>
          <h3>Article One</h3>

          <Link
            to={`/article/${item1.name.replace(/\s+/g, "-").toLowerCase()}/1`}
          >
            <h4>{item1.name}</h4>
          </Link>
          <h4>{item1.subHeading}</h4>
        </div>
      </div>
      <hr></hr>
      <div className="mt-5 mb-5">
        <div>
          <h3>Article Three</h3>
          <Link
            to={`/article/${item3.name.replace(/\s+/g, "-").toLowerCase()}/3`}
          >
            <h4>{item3.name}</h4>
          </Link>
          <h4>{item3.subHeading}</h4>
        </div>
      </div>
    </>
  );
};
