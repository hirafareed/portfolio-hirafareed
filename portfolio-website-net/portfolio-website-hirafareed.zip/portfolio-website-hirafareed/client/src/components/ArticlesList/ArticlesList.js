import React from "react";
import { Link } from "react-router-dom";
import "../../sass/style.scss";
// import MainImage from "./../images/project-one/mainimage.png";

const ArticlesList = ({ articles }) => (
  <>
    {articles.map((article, key) => (
      <div key={key} className="row  each-work float-left ">
        <div className="col-lg-8 work-image">
          <Link
            to={`/article/${article.name.replace(/\s+/g, "-").toLowerCase()}/${
              key + 1
            }`}
          >
            <img
              className="img-fluid"
              src={article.mainImage}
              alt="article one"
            />
          </Link>
        </div>

        <div className=" float-left text-left col-lg-4 work-info">
          <p className="number"> {article.id}</p>
          <h1 className="name "> {article.name}</h1>
          <p className="type"> {article.type}</p>
          <div className="row">
            <p className="info col-lg-12 col-sm-9">{article.subHeading}</p>
          </div>

          <Link
            to={`/article/${article.name.replace(/\s+/g, "-").toLowerCase()}/${
              key + 1
            }`}
          >
            <p className="viewwork ">view work</p>
          </Link>
        </div>
      </div>
    ))}
  </>
);

export default ArticlesList;
