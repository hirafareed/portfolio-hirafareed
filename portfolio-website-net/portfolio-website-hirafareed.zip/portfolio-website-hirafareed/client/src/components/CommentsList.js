import React from "react";

const CommentsList = ({ comments }) => (
  <>
    <h3></h3>
    {comments && comments.length ? comments.map((comment, key) => (
      <div key={key}>
        <h4>{comment.username}</h4>
        <h4>{comment.text}</h4>
      </div>
    )) : <h4>No comments available</h4> }
  </>
);

export default CommentsList;
