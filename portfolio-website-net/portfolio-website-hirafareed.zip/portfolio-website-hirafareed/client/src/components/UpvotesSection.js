import React, {useState} from "react";
import like from "../images/unlike.png";
import unlike from "../images/like.png";

const UpvotesSection = ({ articleName, upvotes, setArticleInfo }) => {
  const [likeClicked, setlikeClicked] = useState(false);

  const upvoteArticle = async () => {
setlikeClicked(!likeClicked)    
const result = await fetch(`/api/articles/${articleName}/upvote`, {
      method: "post",
    });
    const body = await result.json();
    setArticleInfo(body);
  };

  return (
    <div className="container-xl container-lg">
      <div className="my-container row">
        <div className="col col-centered">
         {likeClicked ?  <img
            className="upvote-image"
            src={like}
            alt="like"
            onClick={() => upvoteArticle()}
            /> : 
                    <img
                    className="upvote-image"
                    src={unlike}
                    alt="unlike"
                    onClick={() => upvoteArticle()}
                    />
                  }
          <p className=" upvote-text">{upvotes} people like this project</p>
        </div>
      </div>
    </div>
  );
};

export default UpvotesSection;
