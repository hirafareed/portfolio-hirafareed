import React from "react";
import { Link } from "react-router-dom";
import { Navbar, Nav } from "react-bootstrap";
import "./MobileMenu.scss";

export default ({ close }) => {
  return (
    <>
      {/* It will be visible on mobile screens */}
      <div className="d-block">
        <Navbar.Brand>
          <Link className="navbar-brand hira" to="/">
            <h1 className="">Hira.</h1>
          </Link>
        </Navbar.Brand>

        <div className="ml-auto popup-menu">
          <Link className="nav-item nav-link popup-link" to="/">
            <h1
              onClick={() => {
                close();
              }}
            >
              Work
            </h1>
          </Link>

          <Link className="nav-item nav-link popup-link" to="/about">
            <h1
              onClick={() => {
                close();
              }}
            >
              About
            </h1>
          </Link>

          <Link className="nav-item nav-link popup-link" to="/contact">
            <h1
              onClick={() => {
                close();
              }}
            >
              Contact
            </h1>
          </Link>
        </div>
      </div>
    </>
  );
};
