import React from "react";
import "../sass/style.scss";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Arrow from "../images/arrow.svg";
import { Accordion } from "react-bootstrap";
import { Button } from "react-bootstrap";

const AboutPage = () => (
  <>
    <div className="container-lg container-xl layout-about">
      <div className="my-container">
        <Row>
          <Col>
            {/* about me */}
            <div className="subheading">
              <hr className="line-about" />
              <h6 className="about-sub ">About</h6>
            </div>
            <br></br>
          </Col>
        </Row>

        {/* about-info */}
        <div className="about-info">
          <Row>
            <Col lg={10} xl={10} sm={10} md={10} xs={10}>
              <h1>
                I’m a product designer <br></br>based in Toronto.
              </h1>
            </Col>
          </Row>
          <Row>
            <Col lg={{ offset: 3 }} xl={{ offset: 3 }}>
              <p>
                Shortly after graduating in Communication Design, I worked on
                several interesting and meaningful design projects. I had the
                urge to explore more and therefore decided to pursue my degree
                in Interactive Media Management from Sheridan College.
              </p>
            </Col>
          </Row>
        </div>

        {/* experience */}
        <Row>
          <Col lg={{ offset: 3 }} xl={{ offset: 3 }}>
            <hr className="line-experience" />
            <h6 className="experience-sub"> Experience </h6>
          </Col>
        </Row>

        <Row>
          <Col lg={{ offset: 3 }} xl={{ offset: 3 }}>
            <div className="experienceContent">
              {/* experience 1 */}
              <Accordion>
                <Row>
                  <Col>
                    <p className="position"> Freelance Designer </p>
                  </Col>
                  <Col>
                    <p className="company">Freelance</p>
                  </Col>
                  <Col>
                    <p className="year"> Jan 2018 - Present </p>
                  </Col>

                  <Col className="d-flex justify-content-center">
                    <Accordion.Toggle as={Button} variant="link" eventKey="0">
                      <img className="more-image" src={Arrow} alt="more" />
                    </Accordion.Toggle>
                  </Col>
                </Row>

                <hr></hr>

                <Accordion.Collapse eventKey="0">
                  <Row>
                    <ul>
                      <li>
                        <h6>Shopify:</h6> Part of the team of designers for
                        Unite conference by Shopify.
                      </li>
                      <li>
                        <h6>Ceridian:</h6> Four month contract with Ceridian as
                        part of their design team to work on digital and print
                        design.
                      </li>
                      <li>
                        <h6>Colliers:</h6> Onsite project to design a report
                        with Colliers.
                      </li>
                      <li>
                        <h6>Barrett and Welsh:</h6> Worked for various clients
                        including Pepsi, TD, and Brampton Transit.
                      </li>
                      <li>
                        <h6>SpinMaster:</h6> Worked on the tags for their brand
                        called “Gund” along with some assets for digital
                        screens.{" "}
                      </li>
                      <p>
                        Also worked with various other companies including
                        Ontario Medical Association, Moneris and Greeniche{" "}
                      </p>
                    </ul>
                  </Row>
                </Accordion.Collapse>
              </Accordion>

              {/* experience 2 */}
              <Accordion>
                <Row>
                  <Col>
                    <p className="position"> Creative Designer </p>
                  </Col>
                  <Col>
                    <p className="company"> EDGE, Sheridan</p>
                  </Col>
                  <Col>
                    <p className="year"> Sept 2019 - Present </p>
                  </Col>
                  <Col className="d-flex justify-content-center">
                    <Accordion.Toggle as={Button} variant="link" eventKey="1">
                      <img className="more-image" src={Arrow} alt="more" />
                    </Accordion.Toggle>
                  </Col>
                </Row>
                <hr></hr>

                <Accordion.Collapse eventKey="1">
                  <Row>
                    <p>
                      At EDGE, I help them with their brand identity for their
                      social media and print design. I also help startups at the
                      EDGE with their branding, posters etc.
                    </p>
                  </Row>
                </Accordion.Collapse>
              </Accordion>

              {/* experience 3 */}
              <Accordion>
                <Row>
                  <Col>
                    <p className="position"> Creative Associate </p>
                  </Col>
                  <Col>
                    <p className="company"> The Nest I/O </p>
                  </Col>
                  <Col>
                    <p className="year">Sept 2016 - Nov 2017 </p>
                  </Col>
                  <Col className="d-flex justify-content-center">
                    <Accordion.Toggle as={Button} variant="link" eventKey="2">
                      <img className="more-image" src={Arrow} alt="more" />
                    </Accordion.Toggle>
                  </Col>
                </Row>
                <hr></hr>

                <Accordion.Collapse eventKey="2">
                  <Row>
                    <p>
                      I was responsible for the design outlook of The Nest I/o
                      and P@sha which included social media, website design,
                      collateral design, as well as helping set up events.
                    </p>
                  </Row>
                </Accordion.Collapse>
              </Accordion>

              <Accordion>
                {/* experience 3 */}
                <Row>
                  <Col>
                    <p className="position"> Graphic Designer </p>
                  </Col>
                  <Col>
                    <p className="company"> Express Tribune</p>
                  </Col>
                  <Col>
                    <p className="year"> Feb 2015 - Aug 2016 </p>
                  </Col>
                  <Col className="d-flex justify-content-center">
                    <Accordion.Toggle as={Button} variant="link" eventKey="3">
                      <img className="more-image" src={Arrow} alt="more" />
                    </Accordion.Toggle>
                  </Col>
                </Row>
                <hr></hr>

                <Accordion.Collapse eventKey="3">
                  <Row>
                    <p>
                      Responsibilities included working on the graphics for
                      daily newspaper and weekly magazines using InDesign.
                    </p>
                  </Row>
                </Accordion.Collapse>
              </Accordion>
            </div>
          </Col>
        </Row>
        {/* end of experience */}

        {/* start of education */}

        <div class="fulleducation"></div>
        <Row>
          <Col lg={{ offset: 3 }} xl={{ offset: 3 }}>
            <hr className="line-education" />
            <h6 className="education-sub"> Education </h6>
          </Col>
        </Row>

        {/* education info */}
        <Row className="fulleducation-info">
          <Col lg={{ offset: 3 }} xl={{ offset: 3 }}>
            <Row>
              <Col xl={9} lg={9} md={9} sm={9} xs={9}>
                <p className="degree">
                  Post-Graduate in Interactive Media Management
                </p>
              </Col>
              <Col xl={3} lg={3} md={3} sm={3} xs={3}>
                <p className="degree">2019-2020 </p>
              </Col>
            </Row>

            <p className="school">Sheridan College</p>
            <div className="education-two">
              <Row>
                <Col xl={9} lg={9} md={9} sm={9} xs={9}>
                  <p className="degree">Bachelors in Communication Design</p>
                </Col>
                <Col xl={3} lg={3} md={3} sm={3} xs={3}>
                  <p className="degree">2011-2014 </p>
                </Col>
              </Row>
              <p className="school">
                Indus valley School of Art and Architecture
              </p>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  </>
);

export default AboutPage;
