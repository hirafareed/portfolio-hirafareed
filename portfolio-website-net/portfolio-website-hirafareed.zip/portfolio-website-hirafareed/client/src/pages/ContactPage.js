import React from "react";
import "../sass/style.scss";

const ContactPage = () => (
  <>
    <div className="container App layout-contact">
      <div className="subheading">
        <hr className="line-contact" />
        <h6 className="contact-sub ">Contact</h6>
      </div>
      <br></br>

      {/* about-info */}
      <div className="contact-info">
        <h1>Let's connect</h1>

        <a href="mailto:hirafareedkapadia@gmail.com">
          hirafareedkapadia@gmail.com
        </a>

        <p>
          Reach out at the email above and share some basic info about your
          project and timeline. I’ll get back to you as soon as possible.
        </p>
        <p className="contact-cheers">
          Cheers,<br></br>Hira
        </p>
      </div>
    </div>
  </>
);

export default ContactPage;
