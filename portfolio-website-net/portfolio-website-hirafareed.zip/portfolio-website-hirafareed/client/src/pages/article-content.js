import ArticleOne from "../images/project-one/mainimage.png";
import ArticleTwo from "../images/project-two/mainimage.png";
import HeaderImage from "../images/project-one/headerimage.png";
import HeaderImage2 from "../images/project-two/headerimage.png";

import ApproahImage1 from "../images/project-one/approahimage1.png";
import ApproahImage2 from "../images/project-two/approahimage2.png";

const articles = [
  {
    mainImage: ArticleOne,
    id: "01",
    name: "talk’n’roll",
    subHeading: "A social app to find gaming events near you",
    type: "Mobile Design –– 2020",
    view: "view work",
    headerText:
      "Roll the dice  with your friends in a fun, new, social board game experience.",
    headerImage: HeaderImage,
    tools: "Figma, Adobe Illustrator",
    timeline: "2 weeks",
    myRole: "Branding, \n User Research, \n UX/UI Design,  \n Prototyping ",
    overview:
      "Talk ’n’ roll help you find gaming events, players, groups. Search local gaming events all in one place, without needing to keep track of different websites and social platforms. Post listings looking for people interested in playing specific games near you.",
    approachImage: ApproahImage1,
    approach:
      "I wanted the app to look fun, colourful because that’s how board games are. ",
    articleLink:
      "https://www.figma.com/proto/TZDAfiowf98P0IWvUyrTqp/BB-Prototyping?node-id=69%3A4&viewport=446%2C373%2C0.18485523760318756&scaling=scale-down",
    articleLinkText: "View Interactive prototype",
  },
  {
    mainImage: ArticleTwo,
    id: "02",
    name: "Wander",
    subHeading:
      "A travel app to log your trips and connect to other travellers",
    type: "Product Design –– 2020",
    view: "view work",
    headerText:
      "Bring together all the pieces of your trip and turn that into a simple day by day narrative. ",
    headerImage: HeaderImage2,
    tools: "Figma, Adobe Illustrator,  \n HTML, CSS,  Javascript",
    timeline: "4 weeks",
    myRole: "Branding, \n User Research, \n UX/UI Design, \nDevelopment",
    overview:
      "Wonder is a travel journal which allows the  user to create a travel profile, log their past trips, connect with other travellers and wish-list their future travel destinations. \n \n The app brings together all the pieces of your trip and turn that into a simple day by day narrative. ",
    approachImage: ApproahImage2,
    approach:
      "I wanted the app to look fun, colourful because that’s how board games are. ",
    articleLink: "/",
    articleLinkText: "Website Coming Soon",
  },
  {
    mainImage: ArticleOne,
    id: "03",
    name: "Interface",
    subHeading: "A social app to find gaming events near you",
    type: "UX Research –– 2020",
    view: "view work",
    tools: "figma, illustrator",
    timeline: "2 weeks",
    myRole: "figma, illustrator",
    overview: "2 weeks",
  },
];

export default articles;
